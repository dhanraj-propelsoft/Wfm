<?php

namespace App\Http\Controllers\Api\Wms;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use Session;
use DB;
use App\Helpers\Helper;

use App\OrganizationPerson;
use App\Organization;


use App\Custom;
use App\AccountVoucher;
use App\AccountVoucherType;
use App\VehicleRegisterDetail;
use App\Transaction;
use App\Person;
use App\Business;
use App\RegisteredVehicleSpec;
use App\VehicleVariant;
use App\People;
use App\VehicleChecklist;
use App\WmsTransaction;
use App\WmsAttachment;
use App\WmsChecklist;
use App\HrmEmployee;
use App\TransactionItem;
use App\BusinessAddressType;
use App\BusinessCommunicationAddress;
use App\TransactionField;
use App\VehicleJobcardStatus;
use App\InventoryItem;
use App\InventoryItemGroup;
use App\VehicleSegmentDetail;
use App\WmsPriceList;
use App\VehicleSpecification;
use App\VehicleSpecificationDetails;
use App\VehicleJobItemStatus;
use App\TaxGroup;
use App\Tax;

use Carbon\Carbon;
use DateTime;
use Image;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Response;

use Illuminate\Support\Facades\Auth;

class JobcardController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    private $successStatus = 200;

    /* public function __construct()
     {
         $this->middleware('auth:api');
	 } */
	 

	 public function create($person_id,$organization_id)
	 {
		
      
       // dd($organization_id);
		$transaction_type = AccountVoucherType::select('account_vouchers.*', 'modules.name AS module')
		->leftjoin('module_voucher', 'module_voucher.voucher_type_id', '=', 'account_voucher_types.id')
		->leftjoin('account_vouchers', 'account_vouchers.voucher_type_id', '=', 'account_voucher_types.id')
		->leftjoin('modules', 'modules.id', '=', 'module_voucher.module_id')
		->where('account_vouchers.organization_id', $organization_id)
		->where('modules.name', 'trade_wms')
		->where('account_vouchers.name', 'job_card')
		->first();
      
        $job_item_status = VehicleJobItemStatus::select('name', 'id')->where('status', '1')->get();
       
        $Defalut_status = VehicleJobItemStatus::select('name', 'id')->where('name', 'open')->first()->id;
    
        if($transaction_type == null) {
			return null;
		}

		$previous_entry = Transaction::where('transaction_type_id', $transaction_type->id)->where('organization_id', $organization_id)->orderby('id', 'desc')->first();
        
      
       // $previous_entry = Transaction::where('transaction_type_id', $transaction_type->id)->where('organization_id', $organization_id)->orderby('id', 'desc')->first();
  
      
     
       if($previous_entry!=null)
       {
           if($previous_entry->gen_no){

               $gen_no= $previous_entry->gen_no + 1;

           }else
           if($previous_entry->order_no){
               
               $order_no=$previous_entry->order_no;
            
               $dum_gen_no='~';
               
               $dum_order_no=Custom::generate_accounts_number($transaction_type->name, $dum_gen_no,  false,null,$organization_id);
               
               $ex_gen_no=Custom::get_string_diff($order_no,$dum_order_no);


               DB::table('transactions')->where('id',$previous_entry->id)->update(['gen_no'=> $ex_gen_no]);
           
               $gen_no=$ex_gen_no+1;
           }
           
    }else{
           $gen_no=$transaction_type->starting_value;
    }		
       //dd($gen_no);
        $voucher_no = Custom::generate_accounts_number($transaction_type->name, $gen_no, false,null,$organization_id);
        
      //  dd($voucher_no);
        $job_card_status = VehicleJobcardStatus::where('status', '1')->select('name', 'id')->get();
        

        $job_status = VehicleJobcardStatus::where('name', 'New')->first()->id;
		

        
        
       // $vehicles_register = VehicleRegisterDetail::select('registration_no', 'id')->where('organization_id', $organization_id)->orderby('registration_no','ASC')->get('registration_no', 'id');
      //  $vehicles_register = VehicleRegisterDetail::leftjoin('wms_vehicle_organizations','wms_vehicle_organizations.vehicle_id','=','vehicle_register_details.id')->get('registration_no', 'vehicle_register_details.id');
         //->where('wms_vehicle_organizations.organization_id', $organization_id)

         $vehicles_register = VehicleRegisterDetail::select('vehicle_register_details.registration_no', 'vehicle_register_details.id')->leftjoin('wms_vehicle_organizations','wms_vehicle_organizations.vehicle_id','=','vehicle_register_details.id')
         ->where('wms_vehicle_organizations.organization_id', $organization_id)->get('registration_no', 'vehicle_register_details.id');
     
        $vehicle_check_list=VehicleChecklist::select('name','display_name','id')->where('organization_id',$organization_id)->get();

    //	dd($organization_id);
    //$items=[];
        $items = InventoryItem::select('inventory_items.id', 'inventory_items.name', 'global_item_categories.display_name AS category', 'inventory_items.include_tax', 'inventory_items.include_purchase_tax')

        ->leftjoin('global_item_models', 'global_item_models.id', '=', 'inventory_items.global_item_model_id')		

        ->leftjoin('global_item_categories','global_item_categories.id','=','global_item_models.category_id')	
        
        ->where('inventory_items.organization_id', $organization_id)
        ->orderby('global_item_categories.display_name')
        ->get();


            $items->each(function ($item) {
                $item->setAppends([]);
            });


		return response()->json(['status'=>1,'transaction_type'=>$transaction_type,'vehicles_register'=>$vehicles_register,'jobcard_number'=>$voucher_no,'checkbox_list'=>$vehicle_check_list,'jobcard_statuses'=>$job_card_status,'c_job_status'=>$job_status,'jobcard_items'=>$items,'jobitem_statuses'=>$job_item_status,'defalut_item_status'=>$Defalut_status], $this->successStatus);
       

	 }



	 public function get_vehicle_datas($id,$organization_id=false) {

       
           
        $vehicle_details = VehicleRegisterDetail::where('id', $id)->first();

       // dd($vehicle_details);
        
        if($vehicle_details->user_type == "0"){
            $customer_id = Person::findorfail($vehicle_details->owner_id)->id;
             
        }

        if($vehicle_details->user_type == "1"){
            $customer_id = Business::findorfail($vehicle_details->owner_id)->id;
        }    
        
         /*$last_updated_datas = VehicleRegisterDetail::select('transactions.id','vehicle_register_details.registration_no','transactions.reference_no','wms_transactions.job_date')->leftjoin('wms_transactions','wms_transactions.registration_id','=','vehicle_register_details.id')->leftjoin('transactions','transactions.id','=','wms_transactions.transaction_id')->where('wms_transactions.jobcard_status_id','8')->orderby('transactions.id',"DESC")->first();*/



        $last_updated_datas = Transaction::select('transactions.id','vehicle_register_details.registration_no','wms_transactions.job_date','transactions.reference_no');
        $last_updated_datas->leftjoin('wms_transactions','wms_transactions.transaction_id','=','transactions.id');
        $last_updated_datas->leftjoin('vehicle_register_details','vehicle_register_details.id','=','wms_transactions.registration_id');
        $last_updated_datas->where('vehicle_register_details.registration_no',$vehicle_details->registration_no);
        $last_updated_datas->where(function ($query) {
                $query->where('wms_transactions.jobcard_status_id', '!=',"8")
                      ->orWhere('wms_transactions.jobcard_status_id', '=',null);
        });
        $last_updated_datas->where('transactions.organization_id',$organization_id);
        $last_updated_datas->orderBy('transactions.id',"DESC");
        $last_updated_data = $last_updated_datas->first();

        //dd($last_updated_data);
               
        if( $last_updated_data == null){
            $job_date="";
            $job_reference_no = "";
        }else{
            $job_date = $last_updated_data->job_date;
            $job_reference_no = $last_updated_data->reference_no;
        }
       






        $spec_values = RegisteredVehicleSpec::select('registered_vehicle_specs.spec_id','vehicle_spec_masters.display_name',
		'registered_vehicle_specs.spec_value')->leftjoin('vehicle_spec_masters','vehicle_spec_masters.id','=','registered_vehicle_specs.spec_id')->where('registered_vehicle_specs.organization_id',$organization_id)->where('registered_vehicle_specs.registered_vehicle_id',$id)->get();
		$vehicle_name = VehicleVariant::select('id','vehicle_configuration')->where('id', $vehicle_details->vehicle_configuration_id)->first();

        /*$specifications = RegisteredVehicleSpec::select('registered_vehicle_specs.spec_id','vehicle_spec_masters.display_name',
'registered_vehicle_specs.spec_value')->leftjoin('vehicle_spec_masters','vehicle_spec_masters.id','=','registered_vehicle_specs.spec_id')->where('registered_vehicle_specs.organization_id',$organization_id)->where('registered_vehicle_specs.registered_vehicle_id',$request->id)->get();*/
           
            $values = [];
            $spec = [];
         foreach ($spec_values as $key => $value) {
             	$values['spec_values'][] = $spec_values[$key]->spec_value;
            	$spec['specification'][] = $spec_values[$key]->display_name;
         }
		
		 
		                        
		$people = People::select('people.first_name', 'people.last_name', 'people.display_name', 'people.mobile_no', 'people.email_address', 'people_titles.id AS title_id', 'genders.id AS gender_id',  
		DB::raw('COALESCE(billing_city.name, "") AS billing_city'), 
		DB::raw('COALESCE(billing_state.name, "") as billing_state'),  
		DB::raw('COALESCE(billing_address.address, "") as billing_address'), 
		DB::raw('COALESCE(billing_address.pin, "") as billing_pin'), 
		DB::raw('COALESCE(billing_address.google, "") as billing_google'), 
		'billing_address.id AS billing_id', 
		DB::raw('COALESCE(shipping_city.name, "") AS shipping_city'), 
		DB::raw('COALESCE(shipping_state.name, "") as shipping_state'), 
		DB::raw('COALESCE(shipping_address.address, "") as shipping_address'), 
		DB::raw('COALESCE(shipping_address.pin, "") as shipping_pin'),  
		DB::raw('COALESCE(shipping_address.google, "") as shipping_google'), 
		'shipping_address.id AS shipping_id');
	$people->leftJoin('genders', 'genders.id', '=', 'people.gender_id');
	$people->leftJoin('people_titles', 'people_titles.id', '=', 'people.title_id');
	$people->leftJoin('people_addresses AS billing_address', function($join)
	{
		$join->on('billing_address.people_id', '=', 'people.id')
		->where('billing_address.address_type', '0');
	});
	$people->leftJoin('people_addresses AS shipping_address', function($join)
	{
		$join->on('shipping_address.people_id', '=', 'people.id')
		->where('shipping_address.address_type', '1');
	});
	
	if($vehicle_details->user_type == 0) {
		$people->where('people.person_id', $customer_id);

	} else if($vehicle_details->user_type == 1) {
		$people->where('people.business_id', $customer_id);

	}
	$people->leftjoin('cities AS billing_city','billing_address.city_id','=','billing_city.id');
	   $people->leftjoin('states AS billing_state','billing_city.state_id','=','billing_state.id');
	$people->leftjoin('cities AS shipping_city','shipping_address.city_id','=','shipping_city.id');
	   $people->leftjoin('states AS shipping_state','shipping_city.state_id','=','shipping_state.id');
	$people->where('people.organization_id', $organization_id);
	
	$person = $people->first();

	$vehicle_check_list=VehicleChecklist::select('name','display_name','id')->where('organization_id',$organization_id)->get();




        if($vehicle_details != null) {
            return response()->json(['status' => 1, 'message' => 'Vehicle Datas Retreived Successfully.', 'data' => [
                'id' => $vehicle_details->id,
                'registration_no' => $vehicle_details->registration_no,
                'name' => $vehicle_name,
                'user_type' => $vehicle_details->user_type, 
                'owner_id' => $customer_id,
                // 'display_name' => $vehicle_details->display_name,
                // 'engine_no' => $vehicle_details->engine_no,
                // 'chassis_no' => $vehicle_details->chassis_no,
                // 'manufacturing_year' => $vehicle_details->manufacturing_year,
                // 'vehicle_category_id' => $vehicle_details->vehicle_category_id, 
                // 'vehicle_make_id' => $vehicle_details->vehicle_make_id, 
                // 'vehicle_model_id' => $vehicle_details->vehicle_model_id, 
                // 'vehicle_variant_id' => $vehicle_details->vehicle_variant_id, 
                // 'vehicle_version' => $vehicle_details->version,
                // 'vehicle_body_type_id' => $vehicle_details->vehicle_body_type_id, 
                // 'vehicle_rim_type_id' => $vehicle_details->vehicle_rim_type_id, 
                // 'vehicle_tyre_type_id' => $vehicle_details->vehicle_tyre_type_id, 
                // 'vehicle_tyre_size_id' => $vehicle_details->vehicle_tyre_size_id, 
                // 'vehicle_wheel_type_id' => $vehicle_details->vehicle_wheel_type_id, 
                // 'vehicle_drivetrain_id' => $vehicle_details->vehicle_drivetrain_id,
                // 'vehicle_usage_id' => $vehicle_details->vehicle_usage_id,
                // 'fuel_type_id' => $vehicle_details->fuel_type_id,
                // 'description' => ($vehicle_details->description != null) ? $vehicle_details->description : "", 
                // 'status' => $vehicle_details->status,
                // 'last_update_date' => $job_date,
                // 'last_update_jc' => $job_reference_no,			
                // 'spec_values' => $values,
                // 'spec' =>  $spec,
                // 'driver'=> $vehicle_details->driver,
                // 'vehicle_permit_type'=>$vehicle_details->permit_type,
                // 'fc_due'=>$vehicle_details->fc_due,
                // 'permit_due'=>$vehicle_details->permit_due,
                // 'tax_due'=>$vehicle_details->tax_due,
                // 'vehicle_insurance'=>$vehicle_details->insurance,
                // 'vehicle_insurance_due'=>$vehicle_details->premium_date,
                // 'bank_loan'=>$vehicle_details->bank_loan,
                // 'month_due_date'=>$vehicle_details->month_due_date,
                // 'warranty_km'=>$vehicle_details->warranty_km,
				// 'warranty_yrs'=>$vehicle_details->warranty_years,
				 'people'=>$person
            ]], $this->successStatus);
        } else {
            return response()->json(['status' => 0, 'message' => 'No Vehicle Datas Available.', 'data' => []], $this->successStatus);
        }
           
    }

    



    public function store(Request $request,$id=null)
    {

               
                $inputs=$request->all();
            
                $jobcard_inputs_json=$inputs['data'];
              //  return response()->json(['status' =>1,'data'=> $jobcard_inputs_json], $this->successStatus);
              //  dd();

                $jobcard_inputs=json_decode($jobcard_inputs_json,true);
              //  $itemData=$jobcard_inputs['jobItemData'][0]['id'];;
               // return response()->json(['status' =>1, $itemData], $this->successStatus);
                //;
              //  $Data=array_merge($request->file('images_inspected'),$request->file('images_progress'),$request->file('images_ready'));
               // $count=$jobcard_inputs["CheckListData"];
              //  $array= (array)$count;
               // return response()->json(['status' => 1,$jobcard_inputs], $this->successStatus);
                $organization_id = $jobcard_inputs['organization_id'];
                $person_id= $jobcard_inputs['Person_id'];


                $employee = HrmEmployee::select('hrm_employees.id')
                ->where('hrm_employees.organization_id', $organization_id)
                ->where('hrm_employees.person_id', $person_id)
                ->first();
               
              //  $CLDArray=array();
               
            

                
               
                $organization = Organization::findOrFail($organization_id);
                $transaction_type = AccountVoucher::where('name', 'job_card')->where('organization_id', $organization_id)->first();
           
		
	
                if($id)
                {
                    $transaction=Transaction::findOrFail($id);

                }else{
                    $transaction= new Transaction;

                }
              
              
                if($id==null)
                {
                    $transaction->order_no =$jobcard_inputs['jobcard_no'];


                    $dum_gen_no='~';
               
                    $dum_order_no=Custom::generate_accounts_number($transaction_type->name, $dum_gen_no,  false,null,$organization_id);
                    
                    $gen_no=Custom::get_string_diff($jobcard_inputs['jobcard_no'],$dum_order_no);


                    $transaction->gen_no= $gen_no;
                    
             
                }else{
            
                }
            

              //  $transaction->order_no =$jobcard_inputs['jobcard_no'];
                $transaction->user_type = $jobcard_inputs['user_type'];
                $transaction->people_id = $jobcard_inputs['people_id'];
                $transaction->transaction_type_id = $transaction_type->id;

               

                
		        $transaction->employee_id = $employee->id;
                $transaction->name = $jobcard_inputs['customer'];
                $transaction->mobile = $jobcard_inputs['customerphone'];
                $transaction->email = $jobcard_inputs['customeremail'];
                $transaction->address = $jobcard_inputs['customeraddress'];
                $transaction->billing_name = $jobcard_inputs['customer'];
                $transaction->billing_mobile = $jobcard_inputs['customerphone'];
                $transaction->billing_email = $jobcard_inputs['customeremail'];
                $transaction->billing_address = $jobcard_inputs['customeraddress'];
                $transaction->shipping_name = $jobcard_inputs['customer'];
                $transaction->shipping_mobile = $jobcard_inputs['customerphone'];
                $transaction->shipping_email = $jobcard_inputs['customeremail'];
                $transaction->shipping_address = $jobcard_inputs['customeraddress'];
                $transaction->tax_type = 2; 
                $transaction->notification_status = 1;
                $transaction->organization_id = $jobcard_inputs['organization_id'];
                
                $transaction->save();
                $transaction_id=$transaction->id;
               
                Custom::userby($transaction, true);

                
                

                if($id) 
                {			
                    
                    $wms_transaction = WmsTransaction::where('transaction_id',$transaction_id)->first();
    
                } else{
    
                    $wms_transaction = new WmsTransaction;
                    //dd($wms_transaction);
                }
               

                $wms_transaction->transaction_id =$transaction_id;
			
				$wms_transaction->registration_id = $jobcard_inputs['registration_id'];
				
			    $wms_transaction->vehicle_complaints= $jobcard_inputs['complaints'];
                $wms_transaction->assigned_to=$employee->id;
                $wms_transaction->job_date = ($jobcard_inputs['jobcard_date']!=null) ? Carbon::parse($jobcard_inputs['jobcard_date'])->format('Y-m-d') : null;
              
                $wms_transaction->job_due_date = ($jobcard_inputs['jobcard_duedate']!=null) ? Carbon::parse($jobcard_inputs['jobcard_duedate'])->format('Y-m-d') : null;
                $wms_transaction->job_completed_date = ($jobcard_inputs['jobcard_duedate']!=null) ? Carbon::parse($jobcard_inputs['jobcard_duedate'])->format('Y-m-d') : null;
                $wms_transaction->jobcard_status_id=$jobcard_inputs['jobcard_status'];
				$wms_transaction->organization_id = $organization_id;
				$wms_transaction->save();

                Custom::userby($wms_transaction, true);

                $JobCardItemArray=$jobcard_inputs['jobItemData'];
             
                                 
                if($id) 
                {			
                    
                  //  $wms_transaction = WmsTransaction::where('transaction_id',$transaction_id)->first();
                                //    DB::table('transaction_items')->where('transaction_items.transaction_id', $transaction_id)->delete();
                  
                                    foreach ($JobCardItemArray as  $obj) {
                                        # code...
                                /* **
                                * @method get_item_rate 
                                        Get the Price,quantity,status of the item.
                                *
                                */

         
                                    $TransItem=TransactionItem::Where(['transaction_id'=>$id,"item_id"=>$obj['id']])->exists();
                                    $ItemData=$this->get_item_rate($organization_id,$jobcard_inputs['registration_id'],$obj['id']);
                                         

                                        if(!$TransItem){


                                   
                                   
                                             // dd($ItemData);

                                            $item = new TransactionItem;
                                            $item->transaction_id = $transaction->id;
                                            $item->item_id=$obj['id'];

                                            $item->parent_item_id =  null;
                                            $item->description =  null;
                                            $item->quantity =  $obj['quantity'];
                                            $item->tax_id =  ($ItemData['tax_id'])?$ItemData['tax_id']:null;

                                            $item->rate =  ($ItemData['segment_price']==null)?$ItemData['base_price']:$ItemData['segment_price'];
                                            $amount=($ItemData['segment_price']==null)?$ItemData['base_price']:$ItemData['segment_price'];
                                            $item->amount = $obj['quantity']*$amount ;
                                            $item->new_selling_price =  null;		

                                            $item->start_time =  Carbon::now();
                                            $item->end_time =  Carbon::now();
                                            $item->assigned_employee_id = $employee->id;
                                            $item->job_item_status = $obj['item_status'];
                                            $item->save();


                                                      // START TAX CALCULATION
                                                      $total_tax = 0;
                                                      $tax_array_text = [];

                                                      $tax_group = TaxGroup::where('id', $obj['id'])->first();
                                                      
          
                                                      if($tax_group != null) {
                                                      
                                                          $taxgroups = DB::table('group_tax')->where('group_id', $tax_group->id)->get();
          
                                                          $original_rate = 0;
          
                                                          $total_tax_value = 0;
          
                                                          foreach ($taxgroups as $t) {
                                                              $taxvalue = Tax::where('id', $t->tax_id)->first();
                                                              $total_tax_value += $taxvalue->value;
                                                          }
                                                          //Inclusive Tax = Rate * Tax / Tax + 100;
                                                          //Original Amount = Rate - Inclusive Tax ;
                                                          $original_rate = $item->rate - ($item->rate * $total_tax_value / ($total_tax_value + 100) );
                                                          
                                                          foreach ($taxgroups as $taxgroup) {
						
                                                                    $tax_value = Tax::where('id', $taxgroup->tax_id)->first();
                                                                    if($tax_value->is_percent == 1) {
                                                                        $tax_amount = ($tax_value->value/100)*(1*$original_rate);
                                                                    } else if($tax_value->is_percent == 0) {
                                                                        $tax_amount = $tax_value->value;
                                                                    }


                                                                    // if($tax_amount != 0) {
                                                                    //     if($transaction_type->name == "purchases" || $transaction_type->name == "credit_note") {
                                                                    //         //Sales Tax is expense, All expenses are debit
                                                                    //         //Vendor (Payables) gives the item, Credit the giver
                                                                    //         $entry[] = ['debit_ledger_id' => $tax_value->purchase_ledger_id, 'credit_ledger_id' => $customer_ledger, 'amount' => $tax_amount];
                                                                    //     } 
                                                                    //     else if($transaction_type->name == "sales" || $transaction_type->name == "sales_cash" || $transaction_type->name == "debit_note" || $transaction_type->name == "job_invoice" || $transaction_type->name == "job_invoice_cash" ) 
                                                                    //     {
                                                                    //         //Sales Tax is liability, Liabilities are credit
                                                                    //         //Customer (Receivables) gets the item, Debit the receiver
                                                                    //         $entry[] = ['debit_ledger_id' => $customer_ledger, 'credit_ledger_id' => $tax_value->sales_ledger_id, 'amount' => $tax_amount];
                                                                    //     }
                                                                    // }
                                                                    $total_tax += $tax_amount;
                                                                    $tax_array_text[] = ["id" => $tax_value->id, "name" => $tax_value->display_name, "value" => $tax_value->value, "is_percent" => $tax_value->is_percent, "amount" => $tax_amount];
                                
                                                      }

                                                                    $item->tax_id = ($item->tax_id) ? $item->tax_id : null;
                                                                    $item->is_tax_percent = ($tax_value != null) ? $tax_value->is_percent : null;
                                                                    if(count($tax_array_text) > 0) {
                                                                            $item->tax = json_encode($tax_array_text);
                                                                    }
                                                                    $item->save();
                                                                }

                                                      // END TAX CALCULATION
                                            


                                            
                                 
                                        }else{

                                  //  $ItemData=$this->get_item_rate($organization_id,$jobcard_inputs['registration_id'],$obj['id']);
                                     
                                    $UpdateTransItem=TransactionItem::Where(['transaction_id'=>$id,"item_id"=>$obj['id']])->firstOrFail();
                                 
                                    $UpdateTransItem->quantity =  $obj['quantity'];  
                                    $UpdateTransItem->rate =  ($ItemData['segment_price']==null)?$ItemData['base_price']:$ItemData['segment_price'];
                                    $amount=($ItemData['segment_price']==null)?$ItemData['base_price']:$ItemData['segment_price'];
                                    $UpdateTransItem->amount = $obj['quantity']*$amount ;
                                    $UpdateTransItem->job_item_status = $obj['item_status'];
                                    $UpdateTransItem->save();

                                     


                                }
                                

                            }

                } else{
                          
                                    foreach ($JobCardItemArray as  $value) {
                                        # code...

                                                                        
                                        $ItemData=$this->get_item_rate($organization_id,$jobcard_inputs['registration_id'],$value['id']);
                                       

                                    $item = new TransactionItem;
                                    $item->transaction_id = $transaction->id;
                                    $item->item_id=$value['id'];
                    
                                    $item->parent_item_id =  null;
                                    $item->description =  null;
                                    $item->quantity =  $value['quantity'];
                                    $item->tax_id =  ($ItemData['tax_id'])?$ItemData['tax_id']:null;

                                    $item->rate =  ($ItemData['segment_price']==null)?$ItemData['base_price']:$ItemData['segment_price'];
                                    $amount=($ItemData['segment_price']==null)?$ItemData['base_price']:$ItemData['segment_price'];
                                    $item->amount = ($value['quantity']*$amount);
                                    $item->new_selling_price =  null;		
                    
                                    $item->start_time =  Carbon::now();
                                    $item->end_time =  Carbon::now();
                                    $item->assigned_employee_id = $employee->id;
                                    $item->job_item_status = $value['item_status'];
                                    $item->save();

                                    

                                                      // START TAX CALCULATION
                                                      $total_tax = 0;
                                                      $tax_array_text = [];

                                                      $tax_group = TaxGroup::where('id', $value['id'])->first();
                                                      
          
                                                      if($tax_group != null) {
                                                      
                                                          $taxgroups = DB::table('group_tax')->where('group_id', $tax_group->id)->get();
          
                                                          $original_rate = 0;
          
                                                          $total_tax_value = 0;
          
                                                          foreach ($taxgroups as $t) {
                                                              $taxvalue = Tax::where('id', $t->tax_id)->first();
                                                              $total_tax_value += $taxvalue->value;
                                                          }
                                                          //Inclusive Tax = Rate * Tax / Tax + 100;
                                                          //Original Amount = Rate - Inclusive Tax ;
                                                          $original_rate = $item->rate - ($item->rate * $total_tax_value / ($total_tax_value + 100) );
                                                          
                                                          foreach ($taxgroups as $taxgroup) {
						
                                                                    $tax_value = Tax::where('id', $taxgroup->tax_id)->first();
                                                                    if($tax_value->is_percent == 1) {
                                                                        $tax_amount = ($tax_value->value/100)*(1*$original_rate);
                                                                    } else if($tax_value->is_percent == 0) {
                                                                        $tax_amount = $tax_value->value;
                                                                    }


                                                                    // if($tax_amount != 0) {
                                                                    //     if($transaction_type->name == "purchases" || $transaction_type->name == "credit_note") {
                                                                    //         //Sales Tax is expense, All expenses are debit
                                                                    //         //Vendor (Payables) gives the item, Credit the giver
                                                                    //         $entry[] = ['debit_ledger_id' => $tax_value->purchase_ledger_id, 'credit_ledger_id' => $customer_ledger, 'amount' => $tax_amount];
                                                                    //     } 
                                                                    //     else if($transaction_type->name == "sales" || $transaction_type->name == "sales_cash" || $transaction_type->name == "debit_note" || $transaction_type->name == "job_invoice" || $transaction_type->name == "job_invoice_cash" ) 
                                                                    //     {
                                                                    //         //Sales Tax is liability, Liabilities are credit
                                                                    //         //Customer (Receivables) gets the item, Debit the receiver
                                                                    //         $entry[] = ['debit_ledger_id' => $customer_ledger, 'credit_ledger_id' => $tax_value->sales_ledger_id, 'amount' => $tax_amount];
                                                                    //     }
                                                                    // }
                                                                    $total_tax += $tax_amount;
                                                                    $tax_array_text[] = ["id" => $tax_value->id, "name" => $tax_value->display_name, "value" => $tax_value->value, "is_percent" => $tax_value->is_percent, "amount" => $tax_amount];
                                
                                                      }

                                                                    $item->tax_id = ($item->tax_id) ? $item->tax_id : null;
                                                                    $item->is_tax_percent = ($tax_value != null) ? $tax_value->is_percent : null;
                                                                    if(count($tax_array_text) > 0) {
                                                                            $item->tax = json_encode($tax_array_text);
                                                                    }
                                                                    $item->save();
                                                                }

                                                      // END TAX CALCULATION


                                }

                    
                // $item = new TransactionItem;
				// $item->transaction_id = $transaction->id;
				// if($method == "remote") {
				// 	$item->item_id = $itemId;
				// } else if($method == "store" || $method == "update" || $method == "lowstock") {
				// 	$item->item_id = $item_id[$i];
				// }
				// $item->parent_item_id = ($parent_item_id[$i]) ? $parent_item_id[$i] : null;
				// $item->description = ($description[$i]) ? $description[$i] : null;
				// $item->quantity = ($quantity[$i]) ? $quantity[$i] : null;
				// $item->rate = ($rate[$i]) ? $rate[$i] : null;
				// $item->amount = ($quantity[$i] && $rate[$i]) ? $quantity[$i]*$rate[$i] : null;	
				// $item->new_selling_price = ($new_selling_price[$i]) ? $new_selling_price[$i] : null;			

				// $item->start_time = ($start_time[$i]) ? $start_time[$i] : null;
				// $item->end_time = ($end_time[$i]) ? $end_time[$i] : null;
				// $item->assigned_employee_id = ($assigned_employee_id[$i]) ? $assigned_employee_id[$i] : null;
				// $item->job_item_status = ($job_item_status[$i]) ? $job_item_status[$i] : null;



				// $item->save();
                    //dd($wms_transaction);
                }
            
               
               
               
            






			



                $Inspected_Images=$request->hasFile('images_inspected');
                $Progress_Images=$request->hasFile('images_progress');
                $Ready_Images=$request->hasFile('images_ready');
                
              
                if($Inspected_Images)
                {
                        $FileArray=$request->file('images_inspected');
                        
                       $this->wms_attachments($FileArray,$organization_id,$transaction_id,$image_category=1);
               
                }

                if($Progress_Images)
                {
                        $FileArray=$request->file('images_progress');
                        
                        $this->wms_attachments($FileArray,$organization_id,$transaction_id,$image_category=2);
                }

                if($Ready_Images)
                {
                        $FileArray=$request->file('images_ready');
                        
                        $this->wms_attachments($FileArray,$organization_id,$transaction_id,$image_category=3);
                }

               
                if($jobcard_inputs["CheckListData"])
                {
                        $CheckListInputs=json_decode($jobcard_inputs["CheckListData"],true);
                        
                        // if(count($CheckListInputs)>0)
                        // {
                            DB::table('wms_checklists')->where('transaction_id', $transaction_id)->delete();
                        // }
                        for($i=0; $i<count($CheckListInputs); $i++){



                        

                           // return response()->json(['status' => 1,'data'=>$JsonData[$i]['CheckList_id']], $this->successStatus);



                                    $Data=["transaction_id" => $transaction->id,"checklist_id" => $CheckListInputs[$i]['CheckList_id'],"checklist_notes"=> $CheckListInputs[$i]['CheckList_Comments'],"checklist_status" => 1];
                                //  dd($Data);
                                    $WmsChecklist =WmsChecklist::updateOrCreate(["id"=>""],$Data);
                                    //	Custom::userby($WmsChecklist, true);
                              
                            
                        }
                }
              
                return response()->json(['status' =>1], $this->successStatus);

                
          

    }

    public function wms_attachments($attachments,$organization_id,$transaction_id,$image_category)
    {
       
            //dd($request->all());
            $ImgData=[];
            
             foreach($attachments as $file)
    
                {
                                $FileName_origional=$file->getClientOriginalName();
                                
                                $dt= new DateTime();
                    
                                $file_name_array=explode(".", $file->getClientOriginalName());
                                $file_name_array[0]= $file_name_array[0]."_origional";
                                $Modify_filename_origional=implode(".",$file_name_array);

                                $public_path= 'wms_attachments/org_'.$organization_id.'/temp';
                                $path_array = explode('/', $public_path);
    
                                $public_path = '';
    
                                    foreach ($path_array as $p) {
                                        $public_path .= $p."/";
                                        if (!file_exists(public_path($public_path))) {
                                            mkdir(public_path($public_path), 0777, true);
                                        }
                                    }
                          
                                $file->move(public_path($public_path), $Modify_filename_origional);

                                
                             
		 	                              //  $img=Custom::image_resize($file,800,$Modify_filename_origional,$public_path);
                             
                               
                                
                                          
                                             $WmsAttachment = new WmsAttachment;
                                            $WmsAttachment->transaction_id=$transaction_id;
                                            $WmsAttachment->image_name=$FileName_origional;
                                            $WmsAttachment->image_category=$image_category;
                                            $WmsAttachment->image_origional_name=$file->getClientOriginalName();
                                            /*$WmsAttachment->thumbnail_file=$name_thumbnail;*/
                                            $WmsAttachment->origional_file=$Modify_filename_origional;
                                           
                                            $WmsAttachment->organization_id=$organization_id;
                                            $WmsAttachment->save();
                               
                                        //    return response()->json(['status' =>$img], $this->successStatus);

                                    

                }
    
    
             
             
        }


        public  function image_resize($image, $size, $name, $path)
        {
            try {
           
                $extension      =   $image->getClientOriginalExtension();
                $imageRealPath  =   $image->getRealPath();
                
                $dt = new DateTime();
                
               $img = Image::make($imageRealPath); // use this if you want facade style code
                $img->resize(intval($size), null, function($constraint) {
                     $constraint->aspectRatio();
                });
    
                $path_array = explode('/', $path);
    
                $public_path = '';
    
                foreach ($path_array as $p) {
                    $public_path .= $p."/";
                    if (!file_exists(public_path($public_path))) {
                        mkdir(public_path($public_path), 0777, true);
                    }
                }
                 $save=$img->save(public_path($path). '/'. $name);
            }
            catch(Exception $e)
            {
               // return false;
            }
        }
    
    
        public function edit($id,$vehicle_id,$organization_id)
        {
     
                $vehicles_register = VehicleRegisterDetail::where('organization_id', $organization_id)->pluck('registration_no', 'id');

                $job_item_status = VehicleJobItemStatus::select('name', 'id')->where('status', '1')->get();
       
                $Defalut_status = VehicleJobItemStatus::select('name', 'id')->where('name', 'open')->first()->id;
            
                $vehicles_register->prepend('Select Vehicle', '');
                $people_list = People::select('person_id AS id', DB::raw('IF(mobile_no, CONCAT(display_name, " - " , mobile_no), display_name) AS name'), 'person_id')->where('user_type', 0)->where('organization_id', Session::get('organization_id'));
                $business_list = People::select('business_id AS id', DB::raw('IF(mobile_no, CONCAT(display_name, " - " , mobile_no), display_name) AS name'), 'business_id')->where('user_type', 1)->where('organization_id', Session::get('organization_id'));
                $transactions = Transaction::select('name','user_type','mobile','address','order_no','id','people_id','transaction_type_id','email')->where('id', $id)->where('organization_id',$organization_id)->first();
               
                
                $path=url('/').'/public/wms_attachments/org_'.$organization_id.'/temp/';
                $img_path= "CONCAT('$path', origional_file) AS imageurl";
                
                $wms_attachments_before=WmsAttachment::select(DB::raw($img_path),'organization_id','image_name','image_origional_name','thumbnail_file','thumbnail_file','origional_file','transaction_id')->where('transaction_id', $id)->where('image_category', 1)->where('organization_id',$organization_id)->pluck('imageurl');
    
                $wms_attachments_progress=WmsAttachment::select(DB::raw($img_path),'organization_id','image_name','image_origional_name','thumbnail_file','thumbnail_file','origional_file','transaction_id')->where('transaction_id', $id)->where('image_category', 2)->where('organization_id',$organization_id)->pluck('imageurl');
    
                $wms_attachments_after=WmsAttachment::select(DB::raw($img_path),'organization_id','image_name','image_origional_name','thumbnail_file','thumbnail_file','origional_file','transaction_id')->where('transaction_id', $id)->where('image_category', 3)->where('organization_id',$organization_id)->pluck('imageurl');
    
         
    
            //	dd($id);

                $wms_checklist_query=VehicleChecklist::select('vehicle_checklists.name','vehicle_checklists.id as checklist_id','wms_checklists.transaction_id','wms_checklists.checklist_status','wms_checklists.checklist_notes','wms_checklists.id as id')->LeftJoin('wms_checklists', function($join)  use ($id) {

                $join->on('wms_checklists.checklist_id', '=', 'vehicle_checklists.id') ;
    
                $join->where('wms_checklists.transaction_id', '=',$id) ;});
                
                $wms_checklist=$wms_checklist_query->get();
    
    
    
    
            // $reference_transaction_type = null;
    
    
    
            // $reference_transaction = Transaction::find($transactions->reference_id);		
    
    
            
		        $vehicles_register = VehicleRegisterDetail::select('registration_no', 'id')->where('organization_id', $organization_id)->get('registration_no', 'id');
	
                $wms_transaction = WmsTransaction::select('wms_transactions.jobcard_status_id','wms_transactions.job_date','wms_transactions.job_due_date','wms_transactions.job_completed_date','wms_transactions.registration_id','wms_transactions.id as wms_transcation_id','wms_transactions.vehicle_complaints','vehicle_variants.vehicle_configuration')
    
                ->leftjoin('vehicle_register_details', 'vehicle_register_details.id', '=', 'wms_transactions.registration_id')
    
                ->leftjoin('vehicle_variants','vehicle_variants.id','=','vehicle_register_details.vehicle_configuration_id')
    
                ->where('wms_transactions.organization_id', $organization_id)		
    
                ->where('wms_transactions.transaction_id', $transactions->id)
    
                ->first();
                
                $transaction_type = AccountVoucherType::select('account_vouchers.*', 'modules.name AS module')
    
                ->leftjoin('module_voucher', 'module_voucher.voucher_type_id', '=', 'account_voucher_types.id')
    
                ->leftjoin('account_vouchers', 'account_vouchers.voucher_type_id', '=', 'account_voucher_types.id')
    
                ->leftjoin('modules', 'modules.id', '=', 'module_voucher.module_id')
    
                ->where('account_vouchers.organization_id', $organization_id)
    
                ->where('modules.name','trade_wms')
    
                ->where('account_vouchers.id', $transactions->transaction_type_id)
    
                ->first();
    
    
    
                $type = $transaction_type->name;
    
    
    
                $previous_entry = Transaction::where('transaction_type_id', $transaction_type->id)->where('organization_id', $organization_id)->orderby('id', 'desc')->first();
    
    
    
                $gen_no = ($previous_entry != null) ? ($previous_entry->gen_no + 1) : $transaction_type->starting_value;
    
    
    
                $voucher_no = Custom::generate_accounts_number($transaction_type->name, $gen_no, false,null,$organization_id);
    
    
    
                $employees = HrmEmployee::select('hrm_employees.id', DB::raw('CONCAT(first_name, " ", COALESCE(last_name, "")) AS name'))->where('organization_id', $organization_id)->pluck('name', 'id');
    
                $employees->prepend('Select Sales Person', '');
    
                $address_type = BusinessAddressType::where('name', 'business')->first();
    
    
    
                $business_id = Organization::find($organization_id)->business_id;
    
    
    
                $business_communication_address = BusinessCommunicationAddress::select('business_communication_addresses.placename', 'business_communication_addresses.mobile_no', 'business_communication_addresses.email_address', 'business_communication_addresses.address', 'cities.name AS city', 'states.name AS state', 'business_communication_addresses.pin')
    
                ->leftjoin('cities', 'business_communication_addresses.city_id', '=', 'cities.id')
    
                ->leftjoin('states', 'cities.state_id', '=', 'states.id')
    
                ->where('address_type', $address_type->id)
    
                ->where('business_id', $business_id)
    
                ->first();
    
                
                $business_company_address = $business_communication_address->address;
    
        
                if($business_communication_address->address != "" && $business_communication_address->city != "") {
    
                    $business_company_address .= "\n";
    
                }
    
    
    
                $business_company_address .= $business_communication_address->city;
    
    
    
                if($business_communication_address->city != "" && $business_communication_address->state != "") {
    
                        $business_company_address .= "\n";
    
                    }       
    
    
    
                     $business_company_address .= $business_communication_address->state." ".$business_communication_address->pin;
    
                    $vehicle_details = VehicleRegisterDetail::where('id', $vehicle_id)->first();
                    
                    $vehicle_name = VehicleVariant::select('id','vehicle_configuration')->where('id', $vehicle_details->vehicle_configuration_id)->first();

    
        
                    $transaction_fields = TransactionField::select('transaction_fields.id', 'transaction_fields.name', 'field_formats.name as field_format', 'field_types.name as field_type', 'transaction_fields.field_format_id', 'transaction_fields.field_type_id', DB::Raw('GROUP_CONCAT(group_fields.name SEPARATOR "`")as group_name'), 'transaction_fields.sub_heading')
    
                    ->leftjoin('field_formats', 'field_formats.id', '=', 'transaction_fields.field_format_id')
    
                    ->leftjoin('field_types', 'field_types.id', '=', 'transaction_fields.field_type_id')
    
                    ->leftjoin('transaction_fields as group_fields', 'group_fields.group_id', '=', 'transaction_fields.id')
    
                    ->where('transaction_fields.transaction_type_id', $transaction_type->id)
    
                    ->where('transaction_fields.status', 1)
    
                    ->groupby('transaction_fields.id')
    
                     ->orderby('transaction_fields.sub_heading')
    
                    ->get();
    
    
    
                    $Vehicle_details = RegisteredVehicleSpec::select('registered_vehicle_specs.spec_id','vehicle_spec_masters.display_name',
    
                    'registered_vehicle_specs.spec_value')
    
                    ->leftjoin('vehicle_spec_masters','vehicle_spec_masters.id','=','registered_vehicle_specs.spec_id')
    
                    ->where('registered_vehicle_specs.organization_id',$organization_id)
    
                    ->where('registered_vehicle_specs.registered_vehicle_id',$vehicle_id)
    
                    ->get();

                       
                    $job_card_status = VehicleJobcardStatus::where('status', '1')->select('name', 'id')->get();
                        
                    $JobItemList = InventoryItem::select('inventory_items.id', 'inventory_items.name', 'global_item_categories.display_name AS category', 'inventory_items.include_tax', 'inventory_items.include_purchase_tax')

                    ->leftjoin('global_item_models', 'global_item_models.id', '=', 'inventory_items.global_item_model_id')		
                
                    ->leftjoin('global_item_categories','global_item_categories.id','=','global_item_models.category_id')	
                    
                    ->where('inventory_items.organization_id', $organization_id)
                    ->orderby('global_item_categories.display_name')
                    ->get();
                
                    $JobItemList->each(function ($item) {
                        $item->setAppends([]);
                      });

                    
                    
                    
                      /** Transaction Items
                     *     
                     * select('transaction_items.*', 'inventory_items.is_group','vehicle_job_item_statuses.id as item_status','inventory_item_stocks.in_stock','inventory_items.sale_price_data')

                     *  
                     * */
                    
                     


                      $transaction_items = TransactionItem::select('transaction_items.item_id as id','transaction_items.quantity','transaction_items.job_item_status as item_status')

                      ->leftjoin('vehicle_job_item_statuses', 'vehicle_job_item_statuses.id', '=', 'transaction_items.job_item_status','transaction_items.new_selling_price')
          
                      ->leftjoin('inventory_items', 'inventory_items.id', '=', 'transaction_items.item_id')
          
                      ->leftjoin('inventory_item_stocks', 'inventory_item_stocks.id', '=', 'inventory_items.id' )
          
                      ->where('transaction_items.transaction_id', $id)->get();  

                      
                      foreach($transaction_items as $key=>$items){
                        $transaction_items[$key]->id=(int)$items->id;
                        $transaction_items[$key]->quantity=(int)$items->quantity;
                        $transaction_items[$key]->item_status=(int)$items->item_status;
                      }


                    $job_status = VehicleJobcardStatus::where('name', 'New')->first()->id;
		

                    $JobItemsArray=DB::table('transaction_items')->select('id')->where('transaction_items.transaction_id', $id)->get();
                  
                    $JobItemsArray=DB::table('transaction_items')->select('id')->where('transaction_items.transaction_id', $id)->get();
                  
                    $TransactionData=array_merge($wms_transaction->toArray(),$transactions->toArray());
                    
                    $OtherDatas=['vehicles_register'=>$vehicles_register,'checkbox_list'=>$wms_checklist,'vehicle_details'=>$vehicle_name,'wms_attachments_before'=>$wms_attachments_before,'wms_attachments_progress'=>$wms_attachments_progress,'wms_attachments_after'=>$wms_attachments_after,'JobStatuses'=>$job_card_status,'JobCardItemsList'=>$JobItemList,'JobItems'=>$transaction_items];
                    
                    $ReturnData=array_merge($TransactionData,$OtherDatas);

                    return response()->json(['data'=>$ReturnData,'jobitem_statuses'=>$job_item_status,'defalut_item_status'=>$Defalut_status], $this->successStatus);
        
        }

        public function Job_invoice(Request $request)
        {
            //$transaction_type=""

                    // Job Invoice 8-6-2019
                    // Get Job Invoice data depending on organization id and transaction type
                    //
                    $organization_id=$request->org_id;
                    $offset=$request->page;
                    $limit=$request->per_page;

                    $journal_voucher = AccountVoucher::where('name', 'journal')->where('organization_id', $organization_id)->first()->id;
                    $cash_voucher = AccountVoucher::where('name', 'wms_receipt')->where('organization_id', $organization_id)->first()->id;
                    $return_voucher = AccountVoucher::where('name', 'credit_note')->where('organization_id', $organization_id)->first()->id;
        
                    
                    $transaction_sales = AccountVoucher::where('name', 'job_invoice')->where('organization_id', $organization_id)->first()->id;

                    $transaction_cash = AccountVoucher::where('name', 'job_invoice_cash')->where('organization_id', $organization_id)->first()->id;
            
                    $transaction = Transaction::select('transactions.id', 'transactions.order_no','transactions.approved_on','vehicle_register_details.id as vehicle_id',
                    DB::raw("DATE_FORMAT(transactions.date, '%d %b, %Y') as date"), 
                    DB::raw("DATE_FORMAT(transactions.due_date, '%d %b, %Y') as due_date"),'transactions.date as original_date', 'transactions.due_date as original_due_date','transactions.total', 
                    DB::raw(" IF(transactions.transaction_type_id = $transaction_cash, 0, IF( (SELECT SUM(account_transactions.amount) FROM account_entries LEFT JOIN account_transactions ON account_transactions.entry_id = account_entries.id WHERE account_entries.reference_transaction_id = transactions.id AND account_entries.voucher_id IN ($journal_voucher, $cash_voucher, $return_voucher)) IS NULL,  transactions.total,  transactions.total -  (SELECT SUM(account_transactions.amount) FROM account_entries LEFT JOIN account_transactions ON account_transactions.entry_id = account_entries.id WHERE account_entries.reference_transaction_id = transactions.id AND account_entries.voucher_id IN ($journal_voucher, $cash_voucher, $return_voucher)) ) ) AS balance"),  
                    DB::raw(" IF(transactions.transaction_type_id = $transaction_cash, 1, CASE  WHEN (transactions.total - SUM((SELECT SUM(account_transactions.amount) FROM account_entries LEFT JOIN account_transactions ON account_transactions.entry_id = account_entries.id WHERE account_entries.reference_transaction_id = transactions.id AND account_entries.voucher_id IN ($journal_voucher, $cash_voucher, $return_voucher)))) = 0  THEN 1   WHEN transactions.due_date < CURDATE()  THEN 3  WHEN (transactions.total - SUM((SELECT SUM(account_transactions.amount) FROM account_entries LEFT JOIN account_transactions ON account_transactions.entry_id = account_entries.id WHERE account_entries.reference_transaction_id = transactions.id AND account_entries.voucher_id IN ($journal_voucher, $cash_voucher, $return_voucher)))) > 0  THEN 2 ELSE 0  END  ) AS status"),  'transactions.approval_status', 'transactions.transaction_type_id',  
                    DB::raw("IF(people.display_name IS NULL, business.display_name, people.display_name) as customer"),
                    DB::raw("IF(people.display_name IS NULL, business.display_name, CONCAT(people.first_name, ' ', COALESCE(people.last_name))) as customer_contact"),
                    DB::raw("DATE_FORMAT(transactions.shipping_date, '%d %b, %Y') as shipping_date"),
                    DB::raw("COALESCE(transactions.reference_no, '') AS reference_no"),
                    DB::raw('COALESCE(reference_vouchers.display_name, "Direct") as reference_type'),'vehicle_register_details.registration_no','hrm_employees.first_name AS assigned_to','service_types.name as service_type','vehicle_jobcard_statuses.name as jobcard_status','wms_transactions.name as name_of_job','wms_transactions.job_date','wms_transactions.job_due_date','wms_transactions.job_completed_date','wms_transactions.advance_amount');
                

                    $transaction->leftJoin('people', function($join) use($organization_id)
                    {
                        $join->on('people.person_id','=', 'transactions.people_id')
                        ->where('people.organization_id', $organization_id)
                        ->where('transactions.user_type', '0');
                    });
                $transaction->leftJoin('people AS business', function($join) use($organization_id)
                    {
                        $join->on('business.business_id','=', 'transactions.people_id')
                        ->where('business.organization_id', $organization_id)
                        ->where('transactions.user_type', '1');
                    });
                

                $transaction->leftjoin('transactions AS reference_transactions','transactions.reference_id','=','reference_transactions.id');


                $transaction->leftJoin('account_vouchers AS reference_vouchers', 'reference_vouchers.id', '=', 'reference_transactions.transaction_type_id');

                $transaction->leftJoin('wms_transactions', 'transactions.id', '=', 'wms_transactions.transaction_id');

                $transaction->leftJoin('vehicle_jobcard_statuses', 'vehicle_jobcard_statuses.id', '=', 'wms_transactions.jobcard_status_id');

                $transaction->leftJoin('service_types', 'service_types.id', '=', 'wms_transactions.service_type');

                $transaction->leftjoin('vehicle_register_details', 'vehicle_register_details.id', '=', 'wms_transactions.registration_id');

                $transaction->leftJoin('hrm_employees', 'hrm_employees.id', '=', 'wms_transactions.assigned_to');


                $transaction->where('transactions.organization_id', $organization_id);

                   
                    $transaction->where(function ($query) use ($transaction_sales, $transaction_cash) {
                        $query->where('transactions.transaction_type_id', '=', $transaction_sales)
                            ->orWhere('transactions.transaction_type_id', '=', $transaction_cash);
                });

             



                    $transaction->whereNull('transactions.deleted_at');
                    $transaction->where('transactions.notification_status','!=',2);
                    $transaction->groupby('transactions.id');
                   // $transaction->having('status', '=', 0);
                    $transaction->orderBy('transactions.updated_at','desc');
                    $transaction->skip($offset*$limit);
                    $transaction->take($limit);

                    
				/* 
						Search by customer name, jobstatus,jobcard number

						Code By Manimaran - 18-6-2019
						*/
						//Search column

			if(! $request->has('jobcard_no') && ! $request->has('customer_name') ) {
	
				
                $transactions = [];
            
            }else{

                $columnsToSearch = ['transactions.order_no'];
                
                $jobcard_no_query=($request->jobcard_no)?$request->jobcard_no:'';
                
                $customer_name_query=($request->customer_name)?$request->customer_name:'';
                
               
                $searchQuery =[$jobcard_no_query];
                
                //dd($searchQuery);

                $transaction->Where(function ($query) use ($columnsToSearch,$searchQuery)  {
                        
                    foreach($columnsToSearch as $key => $column) {
                    
                        if($searchQuery[$key]!=null)	{

                            $query->Where($column, 'LIKE', '%' . $searchQuery[$key]. '%');
                        }
                    }  
            }); 

            $SearchCustomer=[$customer_name_query,$customer_name_query];
           
            $columnsToSearch_Cust = ['business.display_name','people.display_name'];

            $transaction->Where(function ($query) use ($columnsToSearch_Cust,$SearchCustomer)  {
                        
                foreach($columnsToSearch_Cust as $key => $column) {
                
                    if($SearchCustomer[$key]!=null)	{

                        $query->orWhere($column, 'LIKE', '%' . $SearchCustomer[$key]. '%');
                    }
                }  
        }); 
        


              $transactions = $transaction->get();
            }

    /* 
        END	Search by customer name, jobstatus,jobcard number
            */
    


                   
                   
                  
                    $message['data'] =["jobInvoice"=>$transactions];
                    
                    return response()->json( $message['data'], $this->successStatus);
 

        }

        
	public function estimation_sms(Request $request,$organization_id )
	{
    //dd($request->all());
    
    
                    $sms_date =Carbon::now();
                    $current_date =  $sms_date->format('d-m-Y');

                   
                        $org_id = $organization_id;
                        

                    //dd($org_id);
                        
                 //   $organization_id =session::get('organization_id');
                    $id=$request->id;
                    $sms_content_requerment=Transaction::select('vehicle_register_details.registration_no as vehicle_no','transactions.name','transactions.mobile')->leftjoin('wms_transactions','wms_transactions.transaction_id','=','transactions.id')->leftjoin('vehicle_register_details','vehicle_register_details.id','=','wms_transactions.registration_id')->where('transactions.id',$id)->get();
                    //dd($sms_content_requerment);
                    foreach ($sms_content_requerment as $key => $value) {
                        $vehicle=$value->vehicle_no;
                        $mobile_no=$value->mobile;
                        $customer_name=$value->name;
                    }
                    

                    /* 
                      Hence User can send the message to alternative mobile_number;
                      if mobile number is exist send message this number
                    */
                    $mobile_no=($request->mobile_no)?$request->mobile_no:$mobile_no;
                   
                    if($request->mobile_no){

                        $transaction_update= Transaction::findorfail($id);
                        $transaction_update->mobile=$request->mobile_no;
                        $transaction_update->save();
                    }



                    $transaction_last = Transaction::select('transactions.transaction_type_id', 'transactions.mobile', 'transactions.id', 'transactions.date', 'transactions.total', DB::raw('COALESCE(transactions.reference_no, "") AS reference_no'), 'transactions.order_no',  
                        DB::raw("IF(people.display_name IS NULL, business.display_name, people.display_name) as customer"), DB::raw('IF(persons.crm_code IS NULL, businesses.bcrm_code, persons.crm_code) AS code')
                        ,DB::raw('transactions.total + wms_transactions.advance_amount as total_amount'));

                        $transaction_last->leftjoin('wms_transactions','wms_transactions.transaction_id','=','transactions.id');
                        $transaction_last->leftJoin('people', function($join) use($organization_id)
                            {
                                $join->on('people.person_id','=', 'transactions.people_id')
                                ->where('people.organization_id', $organization_id)
                                ->where('transactions.user_type', '0');
                            });
                        $transaction_last->leftJoin('people AS business', function($join) use($organization_id)
                            {
                                $join->on('business.business_id','=', 'transactions.people_id')
                                ->where('business.organization_id', $organization_id)
                                ->where('transactions.user_type', '1');
                            });

                        $transaction_last->leftjoin('persons', 'people.person_id', '=', 'persons.id');
                        $transaction_last->leftjoin('businesses', 'business.business_id', '=', 'businesses.id');		
                    
                        $transaction_last->where('transactions.id', $request->id);
                        $transactions = $transaction_last->first();	

                        $transaction_type = AccountVoucher::where('name', $request->input('type'))->where('organization_id', $organization_id)->first();
                        $business_name = Session::get('business');

                       
                            if($transaction_type->name == "job_card" ||$transaction_type->name == "job_request" ||  $transaction_type->name == "job_invoice" || $transaction_type->name == "job_invoice_cash") {				

                                switch ($transaction_type->name) {
                                    case 'job_card':
                                        /*$sms_content =  "Dear ".$transactions->customer.",". "\n\n" ."Your Jobcard Number:".$transactions->order_no." "."for vehicle"." "..$vehicle." "."Created on"." ".$current_date." "."."."Thanks for choosing"." ".$business_name."."."\n\n"."Your Propel ID: ".$transactions->code;*/
                                        $url=url('viewlist/');
                                        $sms_content ="Please note the Jobcard"." ".$transactions->order_no." "."for Vehicle ".$vehicle." "."dated ".$current_date."."."\n\n"."Visit below link for the Status of Job. " . $url . '/' . $id. '/'.$org_id;
                                        $mge ="Job Card";
                                        break;
                                    case 'job_request':
                                        $url=url('viewlist/');
                                        $sms_content="Click  this link to approve estimation  for your vehicle : ".$vehicle." ". $url . '/' . $id. '/'.$org_id."\r\n".$customer_name;
                                        $mge ="Estimation link ";
                                        break;

                                    case 'job_invoice':
                                        $sms_content =  "Dear ".$transactions->customer.",". "\n\n" ."Credit Invoice of Rs. ".$transactions->total." for Invoice Number:".$transactions->order_no." "."Created on"." ".$current_date." "."Thanks for choosing"." ".$business_name."."."\n\n"."Your Propel ID: ".$transactions->code;
                                        $mge = "Invoice";
                                        break;

                                    case 'job_invoice_cash':
                                        $sms_content = "Dear ".$transactions->customer.",". "\n\n" ."Your Payment of Rs. ".$transactions->total." has been received for the Invoice ".$transactions->order_no."". "\n\n" ."Thanks for choosing ".$business_name. "\n\n" ."Your Propel ID: ".$transactions->code;
                                        $mge ="Invoice";

                                        break;
                                }

                                    $msg=Custom::send_transms(config('constants.sms.user'), config('constants.sms.pass'), config('constants.sms.sender'),$mobile_no, $sms_content);

                            }
                        

                    /*$url=url('viewlist/');;
                    $sms_content="Click  this link to approve estimation  for your vehicle : ".$vehicle." ". $url . '/' . $id."\r\n".$customer_name;
                // dd($sms_content);
                    $msg=Custom::send_transms(config('constants.sms.user'), config('constants.sms.pass'), config('constants.sms.sender'),$mobile_no, $sms_content);*/

                    return response()->json(['status' => 1, 'message' =>$mge."  "."sent to ".$mobile_no." for approval", 'data' =>[]]); 
 }


 public function get_item_rate($organization_id,$vehicle_id,$job_item_id) {		


    $transaction_module='trade_wms';
    

    if($transaction_module == 'trade_wms')
    {
        /*Segment*/

        $vehicle_variant_id = VehicleRegisterDetail::findOrFail($vehicle_id)->vehicle_variant_id;

        $variant_name = VehicleVariant::findOrFail($vehicle_variant_id)->name;

        $segments = VehicleSegmentDetail::where('vehicle_variant_name',$variant_name)->first();
                

        if($segments != null)
        {
            $segment_id = VehicleSegmentDetail::where('vehicle_variant_name',$variant_name)->first()->vehicle_segment_id;
        }

        $item_id = WmsPriceList::where('inventory_item_id',$job_item_id)->first();

        /*End Segment*/



        /*Spec*/


        $vehicle_spec = RegisteredVehicleSpec::where('registered_vehicle_id',$vehicle_id)->get();
        

        $spec_id = [];
        $spec_value = [];

        foreach ($vehicle_spec as $key => $value) {
            //$spec_id = $vehicle_spec[$key]->spec_id;
            array_push($spec_id, $vehicle_spec[$key]->spec_id);
            array_push($spec_value, $vehicle_spec[$key]->spec_value);
        }

        
        $VechicleSpec=VehicleSpecification::whereIn('vehicle_spec_id',$spec_id)->get();

        if($spec_value != null) {

        $VechicleSpecName = VehicleSpecificationDetails::select('vehicle_specification_details.id AS value_id','vehicle_specification_details.vehicle_specifications_id','vehicle_specification_details.name','vehicle_specifications.used','vehicle_specifications.pricing')
        ->leftjoin('vehicle_specifications','vehicle_specifications.vehicle_spec_id','=','vehicle_specification_details.vehicle_specifications_id')
        ->where('vehicle_specifications.used','=',1)
        ->where('vehicle_specifications.pricing','=',1)
        ->whereIn('name',$spec_value)
        ->get();

        //dd($VechicleSpecName);

        $value_id = [];
        $spec_array=[];
        $spec_key=1;

        foreach ($VechicleSpecName as $key => $value) {	

            $spec_array["wms_price_lists.spec_value".$spec_key]=$VechicleSpecName[$key]->value_id;
            $spec_key++;
            //array_push($value_id, $VechicleSpecName[$key]->value_id);
        }

        }

        /*End Spec*/

        //dd($spec_array);			
    }		

    

    $category_type = InventoryItem::select('inventory_items.id AS item_id','inventory_items.category_id','inventory_categories.category_type_id')
    ->leftjoin('inventory_categories', 'inventory_categories.id', '=', 'inventory_items.category_id')
    ->where('inventory_items.organization_id', $organization_id)
    ->where('inventory_items.id', $job_item_id)
    ->first();
    


    if($transaction_module != 'trade_wms')
    {
        $item = InventoryItem::select('inventory_items.id', 'inventory_items.name','inventory_items.is_group', 'global_item_category_types.id AS main_category_id','global_item_category_types.name AS category_name', 'inventory_item_stocks.in_stock', DB::raw('COALESCE(inventory_items.minimum_order_quantity, 1) AS minimum_order_quantity'), 'inventory_items.purchase_price', 'inventory_items.sale_price_data', 'inventory_items.tax_id')

            ->leftjoin('global_item_models', 'global_item_models.id', '=', 'inventory_items.global_item_model_id')

            ->leftjoin('global_item_categories', 'global_item_categories.id', '=', 'global_item_models.category_id')

            ->leftjoin('global_item_main_categories', 'global_item_main_categories.id', '=', 'global_item_categories.main_category_id')

            ->leftjoin('global_item_category_types', 'global_item_category_types.id', '=', 'global_item_main_categories.category_type_id')

        //->leftjoin('inventory_categories', 'inventory_categories.id', '=', 'inventory_items.category_id')

        ->leftjoin('wms_price_lists', 'wms_price_lists.inventory_item_id', '=', 'inventory_items.id')			

        ->leftjoin('inventory_item_stocks', 'inventory_item_stocks.id', '=', 'inventory_items.id' )
        ->leftjoin('taxes', 'taxes.id', '=', 'inventory_items.tax_id' )
        ->where('inventory_items.organization_id', $organization_id)
        ->where('inventory_items.id', $job_item_id)			
        ->first();
    }

    //dd($item);

    if($transaction_module == 'trade_wms')
    {
        /*if($item_id != null && $segments != null && $segment_id !=null && $spec_array != null)
        {
            $item = InventoryItem::select('inventory_items.id', 'inventory_items.name','inventory_items.is_group', 'global_item_category_types.id AS main_category_id','global_item_category_types.name AS category_name', 'inventory_item_stocks.in_stock', DB::raw('COALESCE(inventory_items.minimum_order_quantity, 1) AS minimum_order_quantity'), 'inventory_items.purchase_price', 'inventory_items.sale_price_data', 'inventory_items.tax_id','wms_price_lists.price as segment_price')

            ->leftjoin('global_item_models', 'global_item_models.id', '=', 'inventory_items.global_item_model_id')

            ->leftjoin('global_item_categories', 'global_item_categories.id', '=', 'global_item_models.category_id')

            ->leftjoin('global_item_main_categories', 'global_item_main_categories.id', '=', 'global_item_categories.main_category_id')

            ->leftjoin('global_item_category_types', 'global_item_category_types.id', '=', 'global_item_main_categories.category_type_id')		

            ->leftjoin('wms_price_lists', 'wms_price_lists.inventory_item_id', '=', 'inventory_items.id')			

            ->leftjoin('inventory_item_stocks', 'inventory_item_stocks.id', '=', 'inventory_items.id' )
            ->leftjoin('taxes', 'taxes.id', '=', 'inventory_items.tax_id' )
            ->where('inventory_items.organization_id', $organization_id)			
            ->where('inventory_items.id', $request->id)
            ->Where('wms_price_lists.vehicle_segments_id', $segment_id)
            ->Where($spec_array)
            ->first();				
        }*/

        if($item_id != null && $segments != null && $segment_id !=null)
        {
            $item = InventoryItem::select('inventory_items.id', 'inventory_items.name','inventory_items.is_group', 'global_item_category_types.id AS main_category_id','global_item_category_types.name AS category_name', 'inventory_item_stocks.in_stock', DB::raw('COALESCE(inventory_items.minimum_order_quantity, 1) AS minimum_order_quantity'), 'inventory_items.purchase_price', 'inventory_items.sale_price_data', 'inventory_items.tax_id','wms_price_lists.price as segment_price')

            ->leftjoin('global_item_models', 'global_item_models.id', '=', 'inventory_items.global_item_model_id')

            ->leftjoin('global_item_categories', 'global_item_categories.id', '=', 'global_item_models.category_id')

            ->leftjoin('global_item_main_categories', 'global_item_main_categories.id', '=', 'global_item_categories.main_category_id')

            ->leftjoin('global_item_category_types', 'global_item_category_types.id', '=', 'global_item_main_categories.category_type_id')		

            ->leftjoin('wms_price_lists', 'wms_price_lists.inventory_item_id', '=', 'inventory_items.id')			

            ->leftjoin('inventory_item_stocks', 'inventory_item_stocks.id', '=', 'inventory_items.id' )
            ->leftjoin('taxes', 'taxes.id', '=', 'inventory_items.tax_id' )
            ->where('inventory_items.organization_id', $organization_id)
            ->where('inventory_items.id', $job_item_id)
            ->Where('wms_price_lists.vehicle_segments_id', $segment_id)
            //->Where($spec_array)
            ->first();
        }

        /*if($item_id != null && $spec_array != null && $segment_id ==null)
        {
            $item = InventoryItem::select('inventory_items.id', 'inventory_items.name','inventory_items.is_group', 'global_item_category_types.id AS main_category_id','global_item_category_types.name AS category_name', 'inventory_item_stocks.in_stock', DB::raw('COALESCE(inventory_items.minimum_order_quantity, 1) AS minimum_order_quantity'), 'inventory_items.purchase_price', 'inventory_items.sale_price_data', 'inventory_items.tax_id','wms_price_lists.price as segment_price')

            ->leftjoin('global_item_models', 'global_item_models.id', '=', 'inventory_items.global_item_model_id')

            ->leftjoin('global_item_categories', 'global_item_categories.id', '=', 'global_item_models.category_id')

            ->leftjoin('global_item_main_categories', 'global_item_main_categories.id', '=', 'global_item_categories.main_category_id')

            ->leftjoin('global_item_category_types', 'global_item_category_types.id', '=', 'global_item_main_categories.category_type_id')		

            ->leftjoin('wms_price_lists', 'wms_price_lists.inventory_item_id', '=', 'inventory_items.id')			

            ->leftjoin('inventory_item_stocks', 'inventory_item_stocks.id', '=', 'inventory_items.id' )
            ->leftjoin('taxes', 'taxes.id', '=', 'inventory_items.tax_id' )
            ->where('inventory_items.organization_id', $organization_id)			
            ->where('inventory_items.id', $request->id)
            //->Where('wms_price_lists.vehicle_segments_id', $segment_id)
            ->Where($spec_array)
            ->first();				
        }*/

        else
        {

            $item = InventoryItem::select('inventory_items.id', 'inventory_items.name','inventory_items.is_group', 'global_item_category_types.id AS main_category_id','global_item_category_types.name AS category_name', 'inventory_item_stocks.in_stock', DB::raw('COALESCE(inventory_items.minimum_order_quantity, 1) AS minimum_order_quantity'), 'inventory_items.purchase_price', 'inventory_items.sale_price_data', 'inventory_items.tax_id')

            ->leftjoin('global_item_models', 'global_item_models.id', '=', 'inventory_items.global_item_model_id')

            ->leftjoin('global_item_categories', 'global_item_categories.id', '=', 'global_item_models.category_id')

            ->leftjoin('global_item_main_categories', 'global_item_main_categories.id', '=', 'global_item_categories.main_category_id')

            ->leftjoin('global_item_category_types', 'global_item_category_types.id', '=', 'global_item_main_categories.category_type_id')

            //->leftjoin('inventory_categories', 'inventory_categories.id', '=', 'inventory_items.category_id')

            ->leftjoin('wms_price_lists', 'wms_price_lists.inventory_item_id', '=', 'inventory_items.id')			

            ->leftjoin('inventory_item_stocks', 'inventory_item_stocks.id', '=', 'inventory_items.id' )
            ->leftjoin('taxes', 'taxes.id', '=', 'inventory_items.tax_id' )
            ->where('inventory_items.organization_id', $organization_id)
            ->where('inventory_items.id', $job_item_id)			
            ->first();
        }
    }

    $query = InventoryItemGroup::select('inventory_items.name','inventory_items.is_group',DB::raw('COALESCE(inventory_item_groups.price, "") as price'),'inventory_item_groups.quantity','inventory_item_groups.tax_id','inventory_item_groups.item_id');

    $query->leftjoin('inventory_items', 'inventory_items.id', '=', 'inventory_item_groups.item_id');		
    $query->where('inventory_item_groups.item_group_id', $job_item_id);

    $item_group = $query->get();
  //  dd($item);
    if(!$item) abort(404);

    //$sale_price = Custom::get_least_closest_date(json_decode($item->sale_price_data, true), Carbon::parse($request->date)->format('d-m-Y'));

    $sale_price = Custom::get_least_closest_date(json_decode($item->sale_price_data, true));

    //dd($sale_price);

    return ['price' => $sale_price['price'],'base_price' => $sale_price['list_price'],'moq' => $item->minimum_order_quantity, 'tax_id' => $item->tax_id,'is_group' => $item->is_group, 'group' => $item_group,'in_stock' => $item->in_stock,'segment_price' => ($item->segment_price != null) ? $item->segment_price : $sale_price['list_price'],'modules' => $transaction_module,'purchase_price' => ($item->purchase_price != null) ? $item->purchase_price : $sale_price['list_price'],'main_category_type' => $item->category_name, 'main_category_id' => $item->main_category_id];
}





}
