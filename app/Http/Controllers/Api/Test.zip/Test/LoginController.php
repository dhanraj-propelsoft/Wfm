<?php

namespace App\Http\Controllers\Api\Test;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Person;
use Auth;

class LoginController extends Controller
{
	public $successStatus = 200;
	public $unauthorised = 401;

	public function login() {
		
		if(Auth::attempt(['mobile' => request('mobile'), 'password' => request('password'), 'status' => 1])) {
			$user = Auth::user();
			$success['status'] = '1';
			$success['user'] =  $user;
			$success['person_id'] =  $user->person_id;
			$success['propelId'] = Person::find($user->person_id)->crm_code;
			$success['image'] =  "";
			$success['token'] =  $user->createToken($user->name)->accessToken;
			
			// FOR
			
			
			return response()->json($success, $this->successStatus);
		} else {
			return response()->json(['status'=>'Wrong Credentials!'], $this->unauthorised);
		}

	}


	public function logout(Request $request) {

		if($request->user()->token()) {
			$request->user()->token()->revoke();
			$success['status'] =  '1';
			return response()->json($success, $this->successStatus);
		}

		return response()->json(['error'=>'Unauthorised'], $this->unauthorised);


	}
}
