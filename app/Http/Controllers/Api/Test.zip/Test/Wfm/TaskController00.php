<?php

namespace App\Http\Controllers\Api\Wfm;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\wfm_project;
use Session;
use DB;
use App\Helpers\Helper;
class TaskController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    private $successStatus = 200; 

   /* public function __construct()
    {
        $this->middleware('auth:api');
    } */

    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        /*//
           $user = Auth::user();
           $apiKey=$user->createToken($user->name)->accessToken;
           $organization_id = request('organization_id');
           $project_category_list=WfmProjectCategory::where('organization_id',$organization_id)->where('status',1)->pluck('project_category_name','id');
         
            $project_category_list->prepend('select','');
       
     //   return view('wfm.project_create', compact('organization_id'));


        $people = wfm_project::select('person_id AS id', DB::raw('IF(mobile_no, CONCAT(display_name, " - " , mobile_no), display_name) AS name'), 'person_id')->where('user_type', 0)->where('organization_id', $organization_id)->get();

        $message['status'] =  '1';
        $message['people'] =  $people;*/

        return response()->json($message, $this->successStatus);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function Save(Request $request,$id=null)
    {
        //
   
      //  dd($request->all());
        if($id)
        {


        }else{
         $project=new wfm_project;
         $project->project_name=request('project_name');
         $project->project_details=request('project_details');
         $project->organization_id=request('organization_id');
         $project->deadline_date=date_string(request('deadline_date'));
         $project->project_category_id=request('project_category_id');
         $project->created_by=1 ;
         $project->save();
   
        $message['status'] =  '1';
        $message['message'] = 'Project'.config('constants.flash.added');
        $message['latest_projects'] =  wfm_project::orderBy('id', 'desc')->take(5)->pluck("project_name","id");
        $message['projects'] =  wfm_project::orderBy('id', 'desc')->pluck("project_name","id");
        $message['last_added_project'] =  wfm_project::orderBy('id', 'desc')->take(1)->pluck("project_name","id");
        
        }

      

        return response()->json($message, $this->successStatus);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
     public function upload_file(Request $request) {

        $file = $request->file('file');
        $id = $request->input('id');

        $business_id = Organization::findOrFail(Session::get('organization_id'))->business_id;
       // $business_name = Business::findOrFail($business_id)->business_name;

        $path_array = explode('/', 'organizations/'.$business_name.'/items');

        $public_path = '';

        foreach ($path_array as $p) {
            $public_path .= $p."/";
            if (!file_exists(public_path($public_path))) {
                mkdir(public_path($public_path), 0777, true);
            }
        }

        $name = $id.".jpg";

        $request->file('file')->move(public_path($public_path), $name);

        return response()->json(['status'=>1, 'message'=>'Item'.config('constants.flash.updated'),'data'=>['id' => $id, 'path' => URL::to('/').'/public/organizations//'.$name]]);
    }
}
